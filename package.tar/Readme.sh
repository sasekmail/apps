#!/bin/bash
echo "Run code - command 1"
sleep 2
echo "Run code -command 2"
sleep 2
echo "End execution"